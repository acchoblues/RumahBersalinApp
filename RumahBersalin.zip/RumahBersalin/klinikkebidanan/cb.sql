SELECT
FROM
     `daftar